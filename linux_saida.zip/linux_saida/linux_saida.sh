#!/bin/bash

# Define a pasta padrão do Apache
APACHE_ROOT="/var/www/html"

# Remove completamente instalações anteriores
sudo apt purge --auto-remove apache2 mysql-server mysql-client php libapache2-mod-php php-mysql php-mbstring php-xml php-curl php-json php-gd php-imagick -y
sudo apt purge --auto-remove mysql-common -y

# Remove arquivos e configurações anteriores
sudo rm -rf /etc/apache2
sudo rm -rf /etc/mysql
sudo rm -rf /etc/php
sudo rm -rf $APACHE_ROOT/*

# Remove diretórios de instalações anteriores
sudo rm -rf /var/lib/mysql
sudo rm -rf /var/log/mysql
sudo rm -rf /var/log/apache2
sudo rm -rf /var/log/php
sudo rm -rf /var/run/mysqld
sudo rm -rf /var/lib/apache2/*

# Cria uma pasta "saida" no diretório padrão do Apache e define permissões
sudo mkdir -p $APACHE_ROOT/saida
sudo chown -R www-data:www-data $APACHE_ROOT/saida
sudo chmod -R 755 $APACHE_ROOT/saida

# Atualiza a lista de pacotes
sudo apt update

# Instala o Apache, MySQL, PHP e módulos necessários
sudo apt install -y apache2 mysql-server php libapache2-mod-php php-mysql php-mbstring php-xml php-curl php-json php-gd php-imagick

# Configura o Apache para usar UTF-8
echo "AddDefaultCharset UTF-8" | sudo tee -a /etc/apache2/conf-available/charset.conf
sudo a2enconf charset
sudo systemctl restart apache2

# Atualiza a configuração do Apache para apontar para a nova pasta
echo "<Directory $APACHE_ROOT/saida>
    Options Indexes FollowSymLinks
    AllowOverride None
    Require all granted
</Directory>

<VirtualHost *:80>
    DocumentRoot $APACHE_ROOT/saida
    ServerName localhost

    <Directory $APACHE_ROOT/saida>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>

    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>" | sudo tee /etc/apache2/sites-available/saida.conf

# Ativa o novo site
sudo a2ensite saida

# Desativa o site padrão
sudo a2dissite 000-default

# Reinicia o Apache
sudo systemctl restart apache2

# Inicia o MySQL
sudo systemctl start mysql

# Cria o banco de dados e o usuário no MySQL
sudo mysql -u root -p -e "DROP DATABASE IF EXISTS sistema_saida; CREATE DATABASE sistema_saida; DROP USER IF EXISTS 'root'@'localhost'; CREATE USER 'root'@'localhost' IDENTIFIED BY 'root'; GRANT ALL PRIVILEGES ON sistema_saida.* TO 'root'@'localhost'; FLUSH PRIVILEGES;"

# Executa o script SQL diretamente no banco de dados
sudo mysql -u root -p sistema_saida < criar_banco_original.sql

# Extrai os arquivos do sistema para a pasta "saida" e renomeia
unzip -o projeto_saida-main.zip -d $APACHE_ROOT/
sudo mv $APACHE_ROOT/projeto_saida-main $APACHE_ROOT/saida

# Define permissões adequadas para as pastas do projeto, incluindo a biblioteca TCPDF
sudo chown -R www-data:www-data $APACHE_ROOT/saida
sudo chmod -R 755 $APACHE_ROOT/saida

# Reinicia o Apache para aplicar as alterações
sudo systemctl restart apache2

# Cria uma página PHP para testar a conexão com o banco de dados
echo "<?php
\$servername = 'localhost';
\$username = 'root';
\$password = 'root';
\$dbname = 'sistema_saida';

\$conn = new mysqli(\$servername, \$username, \$password, \$dbname);

if (\$conn->connect_error) {
    die('Conexão falhou: ' . \$conn->connect_error);
}

echo 'Conexão bem-sucedida!';
\$conn->close();
?>" | sudo tee $APACHE_ROOT/saida/teste.php

# Reinicia o Apache e o MySQL
sudo systemctl restart apache2 mysql

# Abre o navegador no link de teste no contexto do usuário regular
if sudo -u luana xdg-open http://localhost/teste.php; then
    echo "Navegador aberto com sucesso."
else
    echo "Erro ao abrir o navegador."
fi

# Exibe mensagem de conclusão
echo "Instalação concluída."
# Função para exibir mensagens de sucesso
display_success() {
    echo "Sucesso: $1"
}

# Instala o phpMyAdmin
install_phpmyadmin() {
    sudo apt update
    sudo apt install phpmyadmin

    # Cria um link simbólico para a configuração do Apache
    sudo ln -s /etc/phpmyadmin/apache.conf /etc/apache2/conf-available/phpmyadmin.conf

    # Ativa a configuração e reinicia o Apache
    sudo a2enconf phpmyadmin
    sudo systemctl restart apache2
}

# Define o diretório de instalação do phpMyAdmin
PHPMYADMIN_DIR="/var/www/html/phpmyadmin"

# Instala o phpMyAdmin
install_phpmyadmin

# Exibe mensagem de sucesso
display_success "phpMyAdmin instalado com sucesso em http://localhost/phpmyadmin"
echo " renomei a diretorio para saida que voce baixou no repositorio."
